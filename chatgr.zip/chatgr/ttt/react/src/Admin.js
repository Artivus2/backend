import React, { useState } from "react";

export default function Admin() {
    function handleSubmit(e) {
        const form = e.target;
        const formData = new FormData();
        e.preventDefault();
        formData.append('chat_room_id', 365);
        formData.append('worker_id', 100000933);
        formData.append('chat_role_id', 1);
        

        fetch('/chat/add-member-to-chat', { method: form.method, body: formData },
        {
            headers: {
                "Content-type": "multipart/form-data"
            },
        })
        .then((response) => {
            response.json()
            console.log(response.json())
            })
        .catch((error) => {
            error.json()
            console.log(error.json())
            });

    }
  
  return (
    <form method="post" onSubmit={handleSubmit}>
      
      <div>Админ в чат</div>
     
      <button type="submit">Присоединиться</button>
    </form>
  );
}
