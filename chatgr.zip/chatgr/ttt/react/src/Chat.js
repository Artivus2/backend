import React, { useState, useEffect } from "react";

export default function Chat() {
    const [messages, setMessages] = useState([]);
  
    const getApiData = async () => {
    const formData = new FormData();
    formData.append('chat_room_id', 365);
    const response = await fetch('/chat/get-messages-by-room', { method: 'POST', body: formData })
     .then((response) => response.json());
    setMessages(response.Items);
    };
  
    useEffect(() => {
      getApiData();
    }, []);
  
    return (
      <div>
        {messages.map((message) => (
            <div> 
              ФИО: {message.worker_full_name}, Сообщение: {message.primary_message}, Дата: {message.date_time}
              {message.attachment && <img className="App-chat-image" src={`/uploads/${message.attachment}`}/>
        
      }
              
            </div>
            
          ))}
      </div>
    );
  }
