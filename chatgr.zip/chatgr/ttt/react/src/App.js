import './App.css';
import Form from './Form';
import Chat from './Chat';
import Room from './Room';
import Admin from './Admin';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div className='App-chat'>
          Чат
        </div>
        <div className='App-chat-content'>
        <Chat />
        </div>

        <div className='App-actions'>
        
        <Form />
        </div>


        <div className='App-room'>
        
        <Room />
        </div>

        <div className='App-actions'>
        
        <Admin />
        </div>




        
      </header>
    </div>
  );
}



export default App;





