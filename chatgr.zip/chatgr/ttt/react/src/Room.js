import React, { useState } from "react";

export default function Room() {
    function handleSubmit(e) {
        const form = e.target;
        const formData = new FormData(form);
        e.preventDefault();
        //formData.append('title', title);
        formData.append('workers_ids', [1, 4]);

        fetch('/chat/new-room', { method: form.method, body: formData },
        {
            headers: {
                "Content-type": "multipart/form-data"
            },
        })
        .then((response) => {
            response.json()
            console.log(response.json())
            })
        .catch((error) => {
            error.json()
            console.log(error.json())
            });

    }
  
  return (
    <form method="post" onSubmit={handleSubmit}>
      
      <div>Создать комнату</div>
        <input name="title" defaultValue="" />
       
    

        
      
      <button type="submit">Создать</button>
    </form>
  );
}
