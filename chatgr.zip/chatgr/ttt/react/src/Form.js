import React, { useState } from "react";

export default function Form() {
  
  const [file, setFile] = useState(null);
  

  function handleFileChange(e){
    e.preventDefault();
    if (e.target.files[0]) {
        setFile(e.target.files[0]);
    } else {setFile(null)}
    
    if (!e.target.files[0]) return;
  };


  function handleSubmit(e) {
    // Prevent the browser from reloading the page
    const form = e.target;
    const formData = new FormData(form);
    e.preventDefault();

    // Read the form data
    
    if (file?.name) {
    formData.append('attachment_title', file.name);
    formData.append('attachment', file);
    formData.append("attachment_type", 1);
    } else {
      formData.append("attachment_type", "");
    };
    formData.append("sender_worker_id", 1);
    formData.append("chat_room_id", 365);
    
    fetch('/chat/new-message', { method: form.method, body: formData }, {
      headers: {
          "Content-type": "multipart/form-data"
      },
  });

    // Or you can work with it as a plain object:
    //const formJson = Object.fromEntries(formData.entries());
    
  }

  return (
    <form method="post" onSubmit={handleSubmit}>
      
        <input name="text" defaultValue="" />

        <input
        accept="jpg"
        type="file"
        onChange={handleFileChange}
    />

        
      
      <button type="submit">Отправить</button>
    </form>
  );
}
