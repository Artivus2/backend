<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Company;
use app\models\Otdel;
use app\models\Ruk;
use app\models\Subject;
use yii\data\ActiveDataProvider;




class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    // public function actionIndex()
    // {
    //     return $this->render('index');
    // }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionIndex($otdel_id = 1)
    {
        
        

        //Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $model = new ContactForm();
        //$company_id = Yii::$app->request->get("company");
        $otdel_id = Yii::$app->request->get("otdel", 1);
        //$ruk_id = Yii::$app->request->get("ruk");
        $otdel = Otdel::find()->where(['id' => $otdel_id])->one();
        $ruk = Ruk::find()->where(['otdel_id' => $otdel_id])->one();
        $subject = Subject::find();
        
        
        
        $subjects = new ActiveDataProvider([
            'query' => $subject,
            'pagination' => [
                'pageSize' => 10,
            ],
            ]);
        $model->company = $otdel->company->name;
        $model->otdel = $otdel->name;
        $model->ruk = $ruk->fio;
        $model->subject = Yii::$app->request->post('subject');
        $model->body = Yii::$app->request->post('body');
        if ($model->load(Yii::$app->request->post())) {
        $model->save();
        }
    
        
        return $this->render('contact', [
            'model' => $model,
            'list' => $subjects           
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionUpdate($id)
    {
        
        return $this->render('about', ['model' => $model]);
    }

    protected function findModel($id)
    {
        if (($model = Subject::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
