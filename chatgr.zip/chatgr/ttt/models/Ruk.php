<?php

namespace app\models;

use Yii;
/**
 * @SWG\Definition()
 *
 * @SWG\Property(property="id", type="integer", description="ID")
 * @SWG\Property(property="otdel_id", type="string", description="id otdel")
 * @SWG\Property(property="fio", type="string", description="fio")
 */
class Ruk extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'ruk';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id','otdel_id'], 'required'],

            [['fio'], 'string'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'otdel_id' => 'Отдел',
            'fio' => 'ФИО',
        ];
    }


    public function getOtdel()
    {
        return $this->hasOne(Otdel::class, ['otdel_id' => 'id']);
    }

}