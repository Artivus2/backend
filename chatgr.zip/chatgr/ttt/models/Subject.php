<?php

namespace app\models;

use Yii;
/**
 * @SWG\Definition()
 *
 * @SWG\Property(property="id", type="integer", description="ID")
 * @SWG\Property(property="company_id", type="integer", description="id company")
 * @SWG\Property(property="otdel_id", type="integer", description="id_otdel")
 * @SWG\Property(property="subject", type="string", description="subject")
 * @SWG\Property(property="body", type="string", description="body")
 */
class Subject extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'subject';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id','company','otdel','ruk', 'subject','body'], 'required'],

            //[['subject','body'], 'string'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'company' => 'Организация',
            'otdel' => 'Отдел',
            'ruk' => 'Ответственный',
            'subject' => 'Тема',
            'body' => 'Сообщение'
        ];
    }

}