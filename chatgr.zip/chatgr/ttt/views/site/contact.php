<?php

/** @var yii\web\View $this */
/** @var yii\bootstrap5\ActiveForm $form */
/** @var app\models\ContactForm $model */

use yii\bootstrap5\ActiveForm;
use yii\bootstrap5\Html;
use yii\captcha\Captcha;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use app\models\Company;
use app\models\Otdel;
use app\models\Ruk;
use app\models\Subject;
use yii\data\ActiveDataProvider;
use yii\widgets\DetailView;
use yii\grid\GridView;
use yii\grid\ActionColumn;
use yii\grid\DataColumn;

$this->title = 'Обращение';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-contact">
    <h1><?= Html::encode($this->title) ?></h1>

    
        
        <p>
            Если у вас какие то вопросы, напишите нам
        </p>

        <div class="row">
            <div class="col-lg-5">

                <?php $form = ActiveForm::begin(['id' => 'contact-form']); ?>

                    <?= $form->field($model, 'company') ?>

                    <?= $form->field($model, 'otdel') ?>

                    <?= $form->field($model, 'ruk') ?>

                    <?= $form->field($model, 'subject') ?>

                    <?= $form->field($model, 'body')->textarea(['rows' => 6]) ?>

                    <div class="form-group">
                        <?= Html::submitButton('Отправить', ['class' => 'btn btn-primary', 'name' => 'contact-button']) ?>
                    </div>

                <?php ActiveForm::end(); ?>

            </div>
        </div>


        <div>Список замечаний</div>
<?php
   echo GridView::widget([
       'dataProvider' => $list,
       'tableOptions' => [
            
        'class'=>'table table-striped table-responsive'
        ],
       'columns' => [
           
           [
            'label' => 'Организация',
            
            'value' => function($data){return $data->company;} 
           ],
           [
            'label' => 'Отдел/помещение',
            
            'value' => function($data){return $data->otdel;} 
           ],
           [
            'label' => 'Руководитель/ответственный',
            
            'value' => function($data){return $data->ruk;} 
           ],
           [
            'label' => 'Тема',
            
            'value' => function($data){return $data->subject;} 
           ],
           [
            'label' => 'Обращение',
            
            'value' => function($data){return $data->body;} 
           ],
           
        ],

    ])
 ?>

</div>
