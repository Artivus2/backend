<div class="admin-default-index">
    <h1><?= $this->context->action->uniqueId ?></h1>
    <p>
        Админ панель GREENAVI
    </p>

</div>
